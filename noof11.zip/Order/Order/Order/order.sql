-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2024 at 01:15 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `order`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookingsalon`
--

CREATE TABLE `bookingsalon` (
  `id` int(11) NOT NULL,
  `salonName` varchar(50) NOT NULL,
  `customerEmail` varchar(50) NOT NULL,
  `bookingDate` date NOT NULL,
  `bookingTime` time(6) NOT NULL,
  `services` varchar(50) NOT NULL,
  `totalAmount` varchar(20) NOT NULL,
  `payMode` varchar(20) NOT NULL,
  `accountNumber` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `dateTimeBooking` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookingsalon`
--

INSERT INTO `bookingsalon` (`id`, `salonName`, `customerEmail`, `bookingDate`, `bookingTime`, `services`, `totalAmount`, `payMode`, `accountNumber`, `password`, `dateTimeBooking`) VALUES
(1, 'Salon Maha', 'ahmad@gmail.com', '2024-01-10', '07:24:00.000000', 'makeup', '16', 'cash', '1000000000000023654', '123', '2024-01-10'),
(3, 'Salon Nour', 'ahmad@gmail.com', '2024-01-11', '08:36:00.000000', 'makeup', '16', 'cash', '123100200300456', '123', '2024-01-10'),
(4, 'Salon Maha10', 'ahmad@gmail.com', '2024-01-10', '07:39:00.000000', 'makeup', '16', 'cash', '10023336666210', '100', '2024-01-10'),
(5, 'Salon1', 'ali1@gmail.com', '2024-01-12', '15:35:00.000000', 'manicure', '14', 'cash', '100200300400', '000', '2024-01-10');

-- --------------------------------------------------------

--
-- Table structure for table `bookingtaxi`
--

CREATE TABLE `bookingtaxi` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dateGoing` date NOT NULL,
  `timeGoing` time(6) NOT NULL,
  `dateReturning` date NOT NULL,
  `timeReturn` time(6) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `payMethod` varchar(20) NOT NULL,
  `bankNumber` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `dateTimeBooking` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookingtaxi`
--

INSERT INTO `bookingtaxi` (`id`, `email`, `dateGoing`, `timeGoing`, `dateReturning`, `timeReturn`, `destination`, `payMethod`, `bankNumber`, `password`, `dateTimeBooking`) VALUES
(1, 'ahmad@gmail.com', '2024-01-10', '14:55:00.000000', '2024-01-11', '16:55:00.000000', 'Muscat-Mubeila', 'cash', '100200300400', '123', '2024-01-10');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `emailAddress` varchar(50) NOT NULL,
  `phoneNumber` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `firstName`, `lastName`, `emailAddress`, `phoneNumber`, `password`) VALUES
(4, 'Ahmad', 'Seif', 'ahmad@gmail.com', '97100200', '123');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `id` int(11) NOT NULL,
  `guestName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`id`, `guestName`, `email`, `phone`) VALUES
(5, 'ali2', 'ali1@gmail.com', '98765410');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookingsalon`
--
ALTER TABLE `bookingsalon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookingtaxi`
--
ALTER TABLE `bookingtaxi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookingsalon`
--
ALTER TABLE `bookingsalon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bookingtaxi`
--
ALTER TABLE `bookingtaxi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `guest`
--
ALTER TABLE `guest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;



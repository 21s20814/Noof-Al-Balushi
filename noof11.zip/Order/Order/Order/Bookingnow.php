
<!DOCTYPE html>
<html>
<head>
<title>Order Page</title>
<style>

        body {

    background-image: url(eberhard-grossgasteiger-S-2Ukb_VqpA-unsplash.jpg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 2000px;
    background-color: rgb(141, 98, 98);
     font-family: Arial, sans-serif;
     color:red;
     text-align: center;
     margin: 0;
     padding: 0;
     font-size: 30px;
     
    
        }
        
        </style>

    <b><h1>Book Now</h1></b>
    <br/>
	
	<div>
	<h2>Welcome</h2>
  <?php 
session_start();
$usr=$_SESSION['userID'];
echo"<h3 style='color:white'>" .$usr;
echo"</h3>";
?>
  </div>
    <br/>
   <img src="Screenshot 2024-01-20 210655.png" width="10%" id="ProductImg">
    <br> 
                   <b><a href="Salon.php?id=<?php echo $usr;?>">Salon</a></b>
                   <br><br>

                   <img src="22222.png" width="10%" id="ProductImg">
                   <br>
                   <b><a href="Taxi.php?id=<?php echo $usr;?>">Taxi</a></b> 
				   <br/>
				   <br/>
				    <b><a href="index.php">Back To Home</a></b> 

        </form>
    </body>
</html>
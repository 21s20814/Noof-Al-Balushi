
<?php
$userID=$_GET["id"];

?>

<?php
include 'conn.php';
$conn=OpenCon();
 $valid = 1;
 $error_message="";
 
 if (isset($_POST['cancel'])) {

 echo "<script>window.location.href='bookingnow.php';</script>";
 }
 
if (isset($_POST['booking'])) {
	$email= $_POST['email'];
    $goingDate= $_POST['goingDate'];
    $goingTime=$_POST['goingTime'];
	$returningDate=$_POST['returningDate'];
	$returningTime=$_POST['returningTime'];
	$destination=$_POST['destination'];
	$payment= $_POST['payment'];
	$bankNumber= $_POST['bankNumber'];
	$password= $_POST['password'];
    $dat=date("Y/m/d");
								

 $sql = "INSERT INTO bookingtaxi(email,dateGoing,timeGoing,dateReturning,timeReturn,destination,payMethod,bankNumber,password,dateTimeBooking)
 VALUES('$email','$goingDate','$goingTime','$returningDate','$returningTime','$destination','$payment','$bankNumber','$password','$dat')";
   
    $retval =mysqli_query($conn, $sql) ;
    
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
	$msg="Successfully Booking Salon".$name." Date : ".$date;
   echo "<script>alert('Successfully Booking Taxi'); window.location.href='bookingnow.php';</script>";
       
}
mysqli_close($conn);


?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Taxi Booking</title>

<link rel="stylesheet" href="styles.css">
<style>
   /* Styling for the page */
   body {
    background-image: url(999938.jpg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
     background-color: rgb(242, 249, 251);
     color: rgb(1, 25, 23);
     text-align: center;
     font-family: Arial, sans-serif;
   }
   /* Styling for the form */
   form {
     margin: 50px auto;
     width: 300px;
   }
   .btn-secondary:hover {
    color: #fff;
    background: #8673f2;
   /// margin-top: 2rem;
   }
   /* Styling for labels */
   label {
     display: block;
     margin-bottom: 10px;
   }
   /* Styling for inputs */
   input[type="text"],
   input[type="email"],
   input[type="tel"],
   input[type="date"],
   input[type="time"],
   input[type="password"] {
     width: 100%;
     padding: 8px;
     margin-bottom: 20px;
   }
   /* Styling for submit button */
   input[type="submit"] {
     padding: 10px 20px;
     background-color: white;
     color: black;
     border: none;
     cursor: pointer;
   }
</style>
</head>
<body>
<br/>
<div class="container" style="background-color:white; width:50%;margin: auto;">
<h1 style="color:#F77615;">Taxi Booking </h1>
<hr size="2" color="#FC9C54">
<form action="" method="post">
<!-- Name field -->

<label for="email">Email:</label>
<input type="email" id="destination" name="destination" ><br>
<!-- Date and time of going field -->
<label for="goingDate">Date of going:</label>
<input type="date" id="goingDate" name="goingDate" ><br>
<label for="goingTime">Time of going:</label>
<input type="time" id="goingTime" name="goingTime" ><br>
<!-- Date and time of returning field -->
<label for="returningDate">Date of returning:</label>
<input type="date" id="returningDate" name="returningDate" ><br>
<label for="returningTime">Time of returning:</label>
<input type="time" id="returningTime" name="returningTime" ><br>
<!-- Destination field -->
<label for="destination">Where to go,as well as the number of people:</label>
<input type="text" id="destination" name="destination" ><br>
<!-- Payment method (radio buttons) -->
<table style="background-color:#9DE9F9"> <tr> <td> <label for="payment">Payment Method:</label> </td>
<td><input type="radio" id="bank" name="payment" value="bank" ></td><td><label for="bank">Bank</label> </td>

</tr> </table>
<!-- Bank Number field (displayed only if bank payment method is chosen) -->
<label for="phonenumber">Phone Number:</label>
<input type="text" id="phonenumber" name="phonenumber"><br>

</b>
<!-- Submit button -->
  <br/><br/>
        <input type="submit" value="Booking Taxi" name="booking" class="btn btn-secondary">
		 <input type="submit" value="Cancel" name="cancel" class="btn btn-primary">
</form>
</div>
</body>
</html>




<?php
include 'conn.php';
$conn=OpenCon();
$valid = 1;
$error_message="";
if (isset($_POST['cancel'])) {

echo "<script>window.location.href='index.php';</script>";
}
if (isset($_POST['signIn'])) {

$firstName= $_POST['firstName'];
$lastName= $_POST['lastName'];
$email= $_POST['email'];
$phoneNumber= $_POST['phoneNumber'];
$password=$_POST['password'];
$confirmPassword=$_POST['confirmPassword'];


if(empty($firstName)) {
$valid = 0;
$error_message .= "firstName required"."<br>";
}

if(empty($phoneNumber)) {
$valid = 0;
$error_message .= " phone Number required"."<br>";
}

if(empty($lastName)) {
        $valid = 0;
        $error_message .= "lastName required"."<br>";
    }
    if(empty($email)) {
        $valid = 0;
        $error_message .= "Invalid Email Address "."<br>";
    } else {
            $sql="select emailAddress from customer where emailAddress='$email'";
       $result = mysqli_query($conn,$sql); 
       $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
       $count = mysqli_num_rows($result);                           
            if($count==1) {
                $valid = 0;
                $error_message .= " User ID already Exists"."<br>";
            }
        }
    
    if( empty($password) || empty($confirmPassword) ) {
        $valid = 0;
        $error_message .= "Password and confirmPassword empty"."<br>";
    }

    if( !empty($password) && !empty($confirmPassword) ) {
        if($password != $confirmPassword) {
            $valid = 0;
            $error_message .= "Password and confirmPassword doesnt mutch"."<br>";
        }
    }

    if($valid == 1) {
		
		 $sql = "INSERT INTO customer(firstName,lastName,emailAddress,phoneNumber,password)VALUES('$firstName','$lastName','$email','$phoneNumber','$password')";
   
    $retval =mysqli_query($conn, $sql) ;
    
if(! $retval ) {
die('Could not enter data: ' . mysql_error());
}
echo "<script>alert('Successfully Add new customer !'); window.location.href='singin.php';</script>";

}
mysqli_close($conn);

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Page</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
<h1>New User Registration</h1>
<br/>
<div class="input-group">
<?php
if($error_message != '')
{
echo "<div class='error' style='padding: 0px;margin-bottom:0px;color:red'>".$error_message."</div>";
}
?>
</div>
<form action="" method="post">
    <div class="input-group">
        <label for="firstName">First Name:</label>
        <input type="text" id="firstName" name="firstName">
        
        

    </div>
    <div class="input-group">
    <label for="lastName">Last Name:</label>
     <input type="text" id="lastName" name="lastName">
    </div>

 
    <div class="input-group">

        <label for="email">Email:</label>

        <input type="email" id="email" name="email">

    </div>
 
    <div class="input-group">

        <label for="phoneNumber">Phone Number:</label>

        <input type="tel" id="phoneNumber" name="phoneNumber">

    </div>
 
    <div class="input-group">

        <label for="password">Password:</label>

        <input type="password" id="password" name="password">

    </div>
 
    <div class="input-group">

        <label for="confirmPassword">Confirm Password:</label>

        <input type="password" id="confirmPassword" name="confirmPassword">

    </div>
 
    <div class="input-group">

        <input type="submit" name="signIn" value="Registration" class="btn btn-primary" />

        <input type="submit" value="Cancel" name="cancel" class="btn btn-primary">

    </div>

</form>

</body>
</html>
<style>
body {
font-family: Arial, sans-serif;
margin: 0;
padding: 0;
 background-color: #f7d1d1; /* White background */
 color: #000000; /* Black text */
}
.container {
max-width: 600px;
margin: 100px auto;
padding: 20px;
text-align: center;
border: 1px solid #0b0b0b;
border-radius: 8px;
}
h1 {
margin-bottom: 20px;
}
.input-group {
margin-bottom: 15px;
text-align: left;
}
label {
display: block;
margin-bottom: 5px;
}
input[type="text"],
input[type="email"],
input[type="tel"],
input[type="password"] {
width: calc(50% - 30px);
padding: 8px;
border-radius: 5px;
border: 1px solid #ccc;
}
.btn-secondary:hover {
color: #fff;
background: #931010;
margin-top: 2rem;
}
</style>
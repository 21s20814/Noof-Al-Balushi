<html lang="en"><head>
        <meta charset="UTF-8">
        <meta http-equiv="x-UA-Compatible" content="IE=edge">
        <meta name="viewort" content="width=device-width" ,="" initial-scale="1.0">
        <title> Order </title>
        <!--Style link-->
        <link rel="stylesheet" href="./style.css">
        <!--Fontawsome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    </head>
    <body>
        <!-- Header Start-->
        <header> 
            <div id="navbar" style="">
                <img src="./html.png.png" alt="Order logo">
                
                <nav>
                <u1>
                        <li><a href="Guest.php">Guest</a></li>
                        <li><a href="Singin.php">Register</a></li>
                        <li><a href="Login.php">Login</a></li>
                        <li><a href="order.html">Home</a></li>
                        <li><a href="About.html">About</a></li>
                       
            </u1>
            </nav>
            </div>
            <div class="content">
                <h1>Welcome To E-Business <span class="primery-text">Order</span> </h1>
                <p>Here you will find several salons for booking only for women and several taxis for women and men.</p>
                

            </div>
                                                                          
        </header>


        <!-- Header End-->
        <main>
            <!-- About Start -->
            <section id="About">
                <div class="container">
                    <div class="title">
                        <h2>The E-Business Order History</h2>

                    </div>
                
                        <div class="about-content">
                        <div>
                            <p>We have provided the designs of this site to make it easier to find out about booking an appointment to the salon, which is intended only for women, as well as to book a taxi, which includes women and men, which was completed in 2024, our team has experts and how to deal with the client.</p>
                            <a href="About.html" class="btn btn-secondary">LEARN MORE</a>

                        </div>
                        <img src="./Order.jpg" alt="book">

    
                    </div>
                </div>

            </section>
            <!-- About End -->

        
        
        <!-- Contact Start -->
        <section id="contact">
            <div class="container">
                <div class="contact-content">
                    <div class="contact-info">
                        <div>
                            <h3>ADDRESS</h3>
                            <p><i class="fa-sharp fa-solid fa-location-dot"></i>Muscat, 2 Jan, Oman</p>
                            <p><i class="fa-sharp fa-solid fa-phone-volume"></i> Phone: 79637360</p>
                            <p><i class="fa-solid fa-envelope"></i>noofbalushi123@icloud.com</p>

                        </div>
                    <div>
                    <h3>FOLLOW US</h3>
                        <a href="https://www.facebook.com/profile.php?id=61554826603877&amp;mibextid=kFxxJD"><i class="fa-brands fa-facebook"></i></a>
                        <a href="https://www.instagram.com/order.1oll?igsh=ajJyemRna3oxbTFl&amp;utm_source=qr"><i class="fa-brands fa-instagram"></i></a>
                       
                    </div>
                   </div>
                   <form>
                   <iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1134302.6766510815!2d54.48726989400014!3d21.513261714396224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e95880c5379f649%3A0x2dfe3d4a7e34c93b!2sOman!5e0!3m2!1sen!2sin!4v1629452077891!5m2!1sen!2sin" allowfullscreen="" loading="lazy" width="600" height="300"> </iframe>
 
 
                   </form>
                </div>
            </div>
        </section>
 

        <!-- Contact End -->
    </main>
    <footer id="footer">
       <marquee> <p>Copyright © 2024 All rights reserved | Made by <b><a href="http://127.0.0.1:5500/order.html" target="_blank"> Noof Al-Balushi , Maryam Al-Zaabi , Israa Al-Hasani , Amna Alhinai </a></b></p></marquee>
    </footer>


    
</body></html>
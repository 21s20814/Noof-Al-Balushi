
<?php
include 'conn.php';
$conn=OpenCon();
 $valid = 1;
 $error_message="";
 
 if (isset($_POST['cancel'])) {

 echo "<script>window.location.href='index.php';</script>";
 }
 
if (isset($_POST['booking'])) {
	$email= $_POST['email'];
    $name= $_POST['name'];
    $phoneNumber=$_POST['phone'];	
   		 if(empty($name)) {
        $valid = 0;
        $error_message .= "Name required"."<br>";
    }	
 if(empty($email)) {
        $valid = 0;
        $error_message .= "email required"."<br>";
    }	
 if(empty($phoneNumber)) {
        $valid = 0;
        $error_message .= "phone required"."<br>";
    }
	if($valid == 1) {
	
 $sql = "INSERT INTO guest(guestName,email,phone)
 VALUES('$name','$email','$phoneNumber')";
   
    $retval =mysqli_query($conn, $sql) ;
    
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
	setcookie('User',$user,time()+60*60*7);
        setcookie('pass',$pass,time()+60*60*7);
        session_start();
        $_SESSION['userID']=$email;
   echo "<script>window.location.href='bookingnow.php';</script>";
	}    
}
mysqli_close($conn);


?>






<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <title>Welcome Guest Page</title>

  <link rel="stylesheet" href="styles.css">

</head>

<body>

  <header>

    <h1>Welcome To E-Business Order </h1>

  </header>

  <main>

    <form id="guestForm" method="post" action="">
	<h1>Guest </h1>
	<hr size="2">
	<br/>
	<?php
         if($error_message != '') 
		 {
     echo "<div class='error' style='padding: 0px;margin-bottom:0px;color:red'>".$error_message."</div>";
          }
      ?>
     <label for="email">Name:</label>

      <input type="text" id="name" name="name" ><br><br>

      <label for="email">Email Address:</label>

      <input type="email" id="email" name="email" ><br><br>

      <label for="phone">Phone Number:</label>

      <input type="tel" id="phone" name="phone" ><br><br>

  <br/><br/>
        <input type="submit" value="Booking" name="booking" class="btn btn-secondary">
		 <input type="submit" value="Cancel" name="cancel" class="btn btn-primary">

    </form> 

  </main>

</body>

</html>
<style>

body {

  font-family: Arial, sans-serif;

  background-color: rgb(195, 162, 162);

  color: black;

  margin: 0;

  padding: 0;

}

header {

  text-align: center;

  padding: 20px 0;

}

main {

  display: flex;

  justify-content: center;

  align-items: center;

  height: 80vh;

}

form {

  text-align: center;

}

label {

  display: block;

  margin-bottom: 5px;

}

input[type="email"],

input[type="tel"] ,input[type="text"]{

  padding: 8px;

  margin-bottom: 15px;

  width: 250px;

}

input[type="submit"] {
     padding: 10px 20px;
     background-color: white;
     color: black;
     border: none;
     cursor: pointer;
   }
.btn-secondary:hover {
    color: #fff;
    background: #383838;
    ///margin-top: 2rem;
   }
</style>


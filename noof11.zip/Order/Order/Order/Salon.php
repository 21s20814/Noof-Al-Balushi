<?php
$userID=$_GET["id"];

?>

<?php
include 'conn.php';
$conn=OpenCon();
 $valid = 1;
 $error_message="";
 
 if (isset($_POST['cancel'])) {

 header("Location:bookingnow.php");
exit();
 }
if (isset($_POST['booking'])) {

    $name= $_POST['name'];
	$email= $_POST['email'];
    $date= $_POST['date'];
    $time=$_POST['time'];
	$service=$_POST['service'];
	$totalAmount=$_POST['totalAmount'];
	$payment= $_POST['payment'];
	$bankNumber= $_POST['bankNumber'];

    $dat=date("Y/m/d");
								

 $sql = "INSERT INTO bookingsalon(salonName,customerEmail,bookingDate,bookingTime,services,totalAmount,payMode,accountNumber,password,dateTimeBooking)
 VALUES('$name','$email','$date','$time','$service','$totalAmount','$payment','$bankNumber','$dat')";
   
    $retval =mysqli_query($conn, $sql) ;
    
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
	$msg="Successfully Booking Salon".$name." Date : ".$date;
   echo "<script>alert('Successfully Booking Salon'); window.location.href='bookingnow.php';</script>";
       
}
mysqli_close($conn);



   ?>


<!DOCTYPE html>
<html>
<head>
<title>Salon Reservation</title>
<style>
  body {
    background-image: url(397861593584423.webp);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    background-color: rgb(141, 98, 98);
     font-family: Arial, sans-serif;
     color: rgb(249, 47, 11);
     text-align: center;
     margin: 0;
     padding: 0;
   }
   .container {
     margin-top: 50px;
   }
   .btn-secondary:hover {
    color: #fff;
    background: #383838;
  //  margin-top: 2rem;
   }

   input[type="text"],
   input[type="email"],
   input[type="tel"],
   input[type="date"],
   input[type="time"],
   select {
     padding: 10px;
     margin-bottom: 15px;
     width: 250px;
     text-align: center;
    
   }
   input[type="submit"] {
     padding: 10px 20px;
     background-color: white;
     border: none;
   }

</style>

	  <script type="text/javascript">
var ids = new Array();
ids[0] = "";
ids[1] = 16;
ids[2] = 10;
ids[3] = 14;
ids[4] = 15;
ids[5] = 20;
ids[6] = 14;
ids[7] = 20;
        function Choice() {
            //x = document.getElementById("users");
            y = document.getElementById("service");

              document.getElementById("totalAmount").value = ids[y.selectedIndex];
              
         }


    </script>
</head>
<body>
      <h1>Salon</h1>
      <form action="" method="post">
      
      <input type="text" name="name" placeholder="Salon Name" required><br>
      <input type="Email" name="name" placeholder="Email" required><br>
      <input type="date" name="date" required><br><br>
      <input type="time" name="time" required><br><br>
      <select name="service" id="service" onchange="Choice();"><br>
      <option value="-----">----Select Service------</option>
	  <option value="makeup">Make-up Services</option>
      <option value="hairMassage">Hair Massage</option>
      <option value="manicure">Manicure</option>
      <option value="moroccanBath">Moroccan Bath</option>
      <option value="hairDyeing">Hair Dyeing</option>
      <option value="nailDyeing">Nail Dyeing</option>
      <option value="others">Others</option>
      </select><br>
	  <input type="text" name="totalAmount" placeholder="Total Amount (OMR)" required id="totalAmount" readonly><br>
      <input type="radio" name="payment" value="banking"> Banking<br>
      <input type="text" name="bankNumber" placeholder="Phone Number" required><br>
     <br/><br/>
        <input type="submit" value="Booking" name="booking" class="btn btn-secondary">
		 <a href="index.php"> Back To Home</a>

</form>

</body>
</html>


<?php
include 'conn.php';
$conn=OpenCon();
 $valid = 1;
 $error_message="";
 
 if (isset($_POST['cancel'])) {

 echo "<script>window.location.href='index.php';</script>";
 }
if (isset($_POST['login'])) {

  $phoneNumber= $_POST['phoneNumber']; 
    $pass=$_POST['password'];

if(empty($pass)) {
        $valid = 0;
        $error_message .= "Invalid Password"."<br>";
    }
    if(empty($phoneNumber)) {
      $valid = 0;
      $error_message .= " phone Number required"."<br>";
      }
	
	 
      $sql="select phoneNumber from customer where phoneNumber='$phoneNumber' and password='$pass' ";
       $result = mysqli_query($conn,$sql); 
       $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
       $count = mysqli_num_rows($result); 
       if($count == 1)
	   {
		setcookie('User',$user,time()+60*60*7);
        setcookie('pass',$pass,time()+60*60*7);
        session_start();
        $_SESSION['userID']=$email;
      header("location:Bookingnow.php");
       }
       else{
  $error_message .= "Invalid email  or password"."<br>";
}   
    
mysqli_close($conn);
		
	}
		
	?>

<!DOCTYPE html>

<html>

<head>

  <title>Registration Page</title>

  <style>
    /* Styling for the page */
    body {
      background-image: url(lum3n--RBuQ2PK_L8-unsplash.jpg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
      background-color: #b99be2; /* Background color between light pink and light blue */

      display: flex;

      justify-content: center;

      align-items: center;

      height: 100vh;

      margin: 0;

      font-family: Arial, sans-serif;

    }

    .registration-box {

      background-color: #0d0d0e; /* Speech box color (light blue) */

      width: 400px;

      padding: 20px;

      border-radius: 8px;

      text-align: center;

      color: white; /* Text color inside speech box */

      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);

    }

    input[type="text"],

    input[type="email"],

    input[type="password"],

    select {

      width: 100%;

      padding: 10px;

      margin: 8px 0;

      border-radius: 4px;

      border: 1px solid #ccc;

      box-sizing: border-box;

    }

    input[type="submit"] {

      background-color: #27ae60;

      color: white;

      padding: 10px 20px;

      border: none;

      border-radius: 4px;

      cursor: pointer;

    }

  </style>

</head>

<body>

<div class="registration-box">
<div>
<?php
         if($error_message != '') 
		 {
     echo "<div class='error' style='padding: 10px;margin-bottom:20px;color:red'>".$error_message."</div>";
          }
      ?>
</div>
  <h2>Login</h2>

  <form action="#" method="post">

   
  <label for="phoneNumber">Phone Number:</label><br>

  <input type="tel" id="phoneNumber" name="phoneNumber" >
   <br> <br>
   
    <label for="phone">Password:</label>

    <input type="password" id="password" name="password" >

   <br><br>
    <input type="submit" value="login" name="login" class="btn btn-secondary">
	<input type="submit" value="Back To Home" name="cancel" class="btn btn-primary">
	<a href="Singin.php"> Create Account</a>

  

  </form>

</div>

</body>

</html>


